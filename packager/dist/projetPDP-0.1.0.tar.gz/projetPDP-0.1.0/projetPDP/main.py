def main():
    print("En live tous les mardi et jeudi à 18h sur twitch.tv/peskoooo")
