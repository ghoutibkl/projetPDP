from distutils.core import setup

setup(
    description="Un tutoriel pas comme les autres..",
    author="pesko",
    author_email="vegeta@projetPDP.fr",
    name="projetPDP",
    packages=["projetPDP"],
    url="https://projetPDP.fr",
    version="0.1.0",
    entry_points={
    "console_scripts":
        ["projetPDP = projetPDP.main:main"],
}
)
